# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0009_delete_datedetails'),
    ]

    operations = [
        migrations.CreateModel(
            name='confirmDetails',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('fdate', models.DateField()),
            ],
        ),
        migrations.RemoveField(
            model_name='grounddetails',
            name='id',
        ),
        migrations.RemoveField(
            model_name='userdetails',
            name='id',
        ),
        migrations.AddField(
            model_name='grounddetails',
            name='gid',
            field=models.AutoField(default=0, serialize=False, primary_key=True),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='userdetails',
            name='email',
            field=models.EmailField(max_length=30, serialize=False, primary_key=True),
        ),
        migrations.AddField(
            model_name='confirmdetails',
            name='femail',
            field=models.ForeignKey(to='webapp.UserDetails'),
        ),
        migrations.AddField(
            model_name='confirmdetails',
            name='fid',
            field=models.ForeignKey(to='webapp.GroundDetails'),
        ),
    ]
