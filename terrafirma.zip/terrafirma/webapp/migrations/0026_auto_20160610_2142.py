# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0025_remove_paymentdetails_payemail'),
    ]

    operations = [
        migrations.AlterField(
            model_name='paymentdetails',
            name='paYNum',
            field=models.CharField(unique=True, max_length=16),
        ),
        migrations.AlterField(
            model_name='paymentdetails',
            name='payCvv',
            field=models.CharField(unique=True, max_length=3),
        ),
    ]
