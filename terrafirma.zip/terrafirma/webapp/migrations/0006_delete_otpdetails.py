# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0005_otpdetails_otpmail'),
    ]

    operations = [
        migrations.DeleteModel(
            name='OTPDetails',
        ),
    ]
