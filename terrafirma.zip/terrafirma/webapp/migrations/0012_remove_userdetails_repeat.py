# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0011_auto_20160608_0305'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='userdetails',
            name='repeat',
        ),
    ]
