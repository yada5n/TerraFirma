# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0017_auto_20160609_1418'),
    ]

    operations = [
        migrations.RenameField(
            model_name='grounddetails',
            old_name='gdescription',
            new_name='gaddress',
        ),
        migrations.AddField(
            model_name='grounddetails',
            name='gamount',
            field=models.CharField(default=0, max_length=10),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='grounddetails',
            name='gpic',
            field=models.ImageField(default='car', upload_to=b''),
            preserve_default=False,
        ),
    ]
