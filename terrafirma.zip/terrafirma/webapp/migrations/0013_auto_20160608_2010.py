# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0012_remove_userdetails_repeat'),
    ]

    operations = [
        migrations.DeleteModel(
            name='OTPDetails',
        ),
        migrations.AlterField(
            model_name='grounddetails',
            name='gid',
            field=models.IntegerField(serialize=False, primary_key=True),
        ),
    ]
