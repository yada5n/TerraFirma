# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0026_auto_20160610_2142'),
    ]

    operations = [
        migrations.AddField(
            model_name='confirmdetails',
            name='fslots',
            field=models.CharField(default='a', max_length=15),
            preserve_default=False,
        ),
    ]
