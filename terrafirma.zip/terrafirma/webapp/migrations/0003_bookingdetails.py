# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0002_grounddetails'),
    ]

    operations = [
        migrations.CreateModel(
            name='BookingDetails',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('bname', models.CharField(max_length=20)),
                ('bemail', models.CharField(max_length=50)),
                ('bphone', models.CharField(max_length=15)),
            ],
        ),
    ]
