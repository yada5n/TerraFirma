# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0021_auto_20160609_1604'),
    ]

    operations = [
        migrations.AddField(
            model_name='grounddetails',
            name='gownemail',
            field=models.EmailField(default='man@gmail.com', max_length=50),
            preserve_default=False,
        ),
    ]
