# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0019_remove_grounddetails_gpic'),
    ]

    operations = [
        migrations.AddField(
            model_name='grounddetails',
            name='gpic',
            field=models.FileField(default='pic', upload_to=b''),
            preserve_default=False,
        ),
    ]
