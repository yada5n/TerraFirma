# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime
from django.utils.timezone import utc


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0004_auto_20160605_1744'),
    ]

    operations = [
        migrations.AddField(
            model_name='otpdetails',
            name='OTPmail',
            field=models.CharField(default=datetime.datetime(2016, 6, 5, 12, 44, 44, 630000, tzinfo=utc), max_length=50),
            preserve_default=False,
        ),
    ]
