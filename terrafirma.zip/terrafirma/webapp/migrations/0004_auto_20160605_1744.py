# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0003_bookingdetails'),
    ]

    operations = [
        migrations.CreateModel(
            name='OTPDetails',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('OTPNum', models.CharField(max_length=20)),
            ],
        ),
        migrations.AlterField(
            model_name='bookingdetails',
            name='bemail',
            field=models.EmailField(unique=True, max_length=254),
        ),
    ]
