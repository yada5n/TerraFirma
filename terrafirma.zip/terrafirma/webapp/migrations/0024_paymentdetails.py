# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0023_auto_20160610_0029'),
    ]

    operations = [
        migrations.CreateModel(
            name='PaymentDetails',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('payEmail', models.EmailField(max_length=50)),
                ('paYNum', models.CharField(max_length=12)),
                ('payCvv', models.CharField(max_length=3)),
            ],
        ),
    ]
