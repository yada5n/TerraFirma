# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webapp', '0010_auto_20160608_0206'),
    ]

    operations = [
        migrations.AlterField(
            model_name='bookingdetails',
            name='bemail',
            field=models.EmailField(max_length=40),
        ),
    ]
