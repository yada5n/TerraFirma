from django.contrib import admin

# Register your models here.
from .forms import UserDetailsForm,GroundDetailsForm,BookingDetailsForm,confirmDetailsForm,OwnerDetailsForm,PaymentDetailsForm
from .models import UserDetails,GroundDetails,BookingDetails,confirmDetails,OwnerDetails,PaymentDetails


class OwnerDetailsAdmin(admin.ModelAdmin):
	class Meta:
		model=OwnerDetails
admin.site.register(OwnerDetails,OwnerDetailsAdmin)

class GroundDetailsAdmin(admin.ModelAdmin):
	class Meta:
		model=GroundDetails
admin.site.register(GroundDetails,GroundDetailsAdmin)

class UserDetailsAdmin(admin.ModelAdmin):
    class Meta:
        model=UserDetails
admin.site.register(UserDetails,UserDetailsAdmin)

class confirmDetailsAdmin(admin.ModelAdmin):
	class Meta:
		model=confirmDetails
admin.site.register(confirmDetails,confirmDetailsAdmin)

class BookingDetailsAdmin(admin.ModelAdmin):
	class Meta:
		model=BookingDetails
admin.site.register(BookingDetails,BookingDetailsAdmin)

class PaymentDetailsAdmin(admin.ModelAdmin):
	class Meta:
		model=PaymentDetails
admin.site.register(PaymentDetails,PaymentDetailsAdmin)		

