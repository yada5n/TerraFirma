from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
import os
import pyotp

from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from django.contrib import auth
from django.shortcuts import get_object_or_404
from django.core.urlresolvers import reverse
from django.core.context_processors import csrf
from django.template import RequestContext
from django.views.generic import FormView,DetailView,ListView
from datetime import datetime

from .forms import UserDetailsForm,GroundDetailsForm,BookingDetailsForm,confirmDetailsForm,OwnerDetailsForm,PaymentDetailsForm
from .models import UserDetails,GroundDetails,BookingDetails,confirmDetails,OwnerDetails,PaymentDetails



userOtpMap = {}
otpEntered = False
idnum = 0

def gen_otp(email):
  if not userOtpMap.has_key(email):
    userOtpMap[email] = pyotp.random_base32()

def main(request):
    return render_to_response('index.html')

# def main(request):
#     if request.session['name'] == '':
#         return render_to_response('index.html',{'val':request.session['name']})
#     else:
#         return render(request,'mainAcc.html',{'val':request.session['name']})

def logout(request):
   request.session['name'] = ''
   return render_to_response('index.html', {'val':request.session['name']})

def ownlogout(request):
   request.session['oname'] = ''
   return render_to_response('index.html', {'val':request.session['oname']})

def login(request):
    args = {}
    args.update(csrf(request))
    return render_to_response('login.html',args)
def backOTP(request):
    return render_to_response('enterOTP.html',{'confirmEmail':bookemail,'val':request.session['name']})

def ownerlogin(request):
    args = {}
    args.update(csrf(request))
    return render_to_response('ownerlogin.html',args)
def ownlogin_auth_view(request):
    global oemail
    global gobOwn
    global j
    oemail = request.POST.get('oemail','')
    opassword = request.POST.get('opassword','')
    try:
        ouser = OwnerDetails.objects.get(oemail = oemail)
    except OwnerDetails.DoesNotExist:
        html = "<html><body>email doesn't match</body></html>"
        return HttpResponse(html)
    if ouser is not None:
        if ouser.opassword == opassword:
            k2 = OwnerDetails.objects.get(oemail = oemail)
            ousername = k2.ousername
            print ousername
            request.session['oname'] = ousername
            request.session['oemail'] = ouser.oemail
            j = OwnerDetails.objects.get(oemail = oemail)
            gobOwn = j.ousername
            print gobOwn
            return HttpResponseRedirect('/webapp/gdet/')
        else:
            html = "<html><body>Password incorrect</body></html>"
            return render_to_response('new.html')
    else:
        html = "<html><body>username incorrect</body></html>"
        return HttpResponse(html)
def gdet(request):
    global k
    args = {}
    args.update(csrf(request))
    k = j.oemail
    return render_to_response('grounddetails.html',{'l':k,'val':request.session['oname']},context_instance=RequestContext(request))
def preregister(request):
    args = {}
    args.update(csrf(request))
    return render_to_response('preregister.html',args)

def prelogin(request):
    args = {}
    args.update(csrf(request))
    return render_to_response('prelogin.html',args)
def grounddetails(request):
    args ={}
    args.update(csrf(request))
    return render_to_response('grounddetails.html',args)

def ownerregister(request):
    args = {}
    args.update(csrf(request))
    return render_to_response('ownerregister.html',args)    

def auth_view(request):
    global email
    global gobName
    email = request.POST.get('email','')
    password = request.POST.get('password','')
    try:
        user = UserDetails.objects.get(email = email)
    except UserDetails.DoesNotExist:
        html = "<html><body>email doesn't match</body></html>"
        return HttpResponse(html)
    if user is not None:
        if user.password == password:
            kl = UserDetails.objects.get(email = email)
            username = kl.username
            print username
            request.session['name'] = username
            request.session['email'] = user.email
            i = UserDetails.objects.get(email = email)
            gobName = i.username
            return render_to_response('mainAcc.html',{'val': username})
        else:
            html = "<html><body>Password incorrect</body></html>"
            return render_to_response('newforlog.html')
    else:
        html = "<html><body>username incorrect</body></html>"
        return HttpResponse(html)
def registration(request):
    args = {}
    args.update(csrf(request))
    return render_to_response('signup.html',args)
def signup(request):
    form = UserDetailsForm()
    if request.POST:
        form = UserDetailsForm(request.POST)
        if form.is_valid():
            print form
            form.save()
            return HttpResponseRedirect('/webapp/login/')
        else:
            temp = "<html><boby>Email-id or the mobile number already exists</body></html>"
            return HttpResponse(temp)
    return render_to_response('signup.html',{'form':form}, context_instance=RequestContext(request))
def signupowner(request):
    form = OwnerDetailsForm()
    if request.POST:
        form = OwnerDetailsForm(request.POST)
        if form.is_valid():
            print form
            form.save()
            return HttpResponseRedirect('/webapp/ownerlogin/')
        else:
            temp = "<html><boby>Email-id or the mobile number already exists</body></html>"
            return HttpResponse(temp)
    return render_to_response('ownerregister.html',{'form':form}, context_instance=RequestContext(request))
def checkowner(request):
    args = {}
    args.update(csrf(request))
    countt = 0
    cnt = 0
    global iemail
    iemail = k
    print iemail
    itype = request.POST["gtype"]
    print itype
    iname = request.POST["gname"]
    print iname
    iaddress = request.POST["gaddress"]
    print iaddress
    iamount = request.POST["gamount"]
    print iamount
    ipic = request.POST["gpic"]
    print ipic
    grndobj = GroundDetails.objects.all()
    if not grndobj:
        countt += 1
        print "///////////////////"
        GroundDetails(gownemail=iemail,gid=countt,gtype=itype,gname=iname,gaddress=iaddress,gamount=iamount,gpic=ipic).save()
        return render_to_response('ownersuccess.html',{'val':request.session['name']})
    else:
        obj6 = GroundDetails.objects.filter(gaddress=iaddress)
        for xa in obj6:
            print "............................."
            return render_to_response('dummyowner.html',{'l':k,'val':request.session['oname']},context_instance=RequestContext(request))
        obj7 = GroundDetails.objects.filter(gname=iname)
        for xb in obj7:
            print "............................."
            return render_to_response('dummyowner1.html',{'l':k,'val':request.session['oname']},context_instance=RequestContext(request))
        cnt = GroundDetails.objects.all().count()
        print cnt
        cnt += 1
        print "$$$$$$$$$$$$"
        print cnt
        GroundDetails(gownemail=iemail,gid=cnt,gtype=itype,gname=iname,gaddress=iaddress,gamount=iamount,gpic=ipic).save()
        return render_to_response('ownersuccess.html',{'val':request.session['oname']},context_instance=RequestContext(request))
            
def ownersuccess(request):
    return render_to_response('ownersuccess.html',{'val':request.session['oname']})

def mainAcc(request):
    return render_to_response('mainAcc.html',{'val':request.session['name']})

def stadiumViews(request):
    obj = GroundDetails.objects.filter(gtype='stadium')
    return render_to_response('stadiumview.html',{'obj':obj,'val':request.session['name']})

def functionViews(request):
    if request.session['name'] == '':
        print "********"
        return render_to_response('index.html')
    print "&&&&&&&&&"
    obj = GroundDetails.objects.filter(gtype='function hall')
    return render_to_response('functionview.html',{'obj':obj,'val':request.session['name']})

def playGroundViews(request):
    obj = GroundDetails.objects.filter(gtype='play ground')
    return render_to_response('playgroundview.html',{'obj':obj,'val':request.session['name']})
       
def bookStadium(request):
    global i
    global idnum
    global grdname
    global obj
    i = request.GET["yoyo1"]
    obj = GroundDetails.objects.filter(gname=i)
    if not obj:
        error = "Please enter valid data"
        obj = GroundDetails.objects.filter(gtype='stadium')
        return render_to_response('stadiumview.html',{'obj':obj,'error':error,'val':request.session['name']})
    else:
        place = GroundDetails.objects.get(gname=i)
        idnum = place.gid
        grdname = place.gname
        return render_to_response('bookstadium.html',{'obj':obj,'val':request.session['name']})    

def bookFunction(request):
    global i
    global idnum
    global grdname
    global obj
    i = request.GET["yoyo1"]
    obj = GroundDetails.objects.filter(gname=i)
    if not obj:
        error = "Please enter valid data"
        obj = GroundDetails.objects.filter(gtype='function hall')
        return render_to_response('functionview.html',{'obj':obj,'error':error,'val':request.session['name']})
    else:
        place = GroundDetails.objects.get(gname=i)
        idnum = place.gid
        grdname = place.gname
        return render_to_response('bookFunction.html',{'obj':obj,'val':request.session['name']})    

def bookPlayGround(request):
    global i
    global idnum
    global grdname
    global obj
    i = request.GET["yoyo1"]
    obj = GroundDetails.objects.filter(gname=i)
    if not obj:
        error = "Please enter valid data"
        obj = GroundDetails.objects.filter(gtype='play ground')
        return render_to_response('playgroundview.html',{'obj':obj,'error':error,'val':request.session['name']})
    else:
        place = GroundDetails.objects.get(gname=i)
        idnum = place.gid
        grdname = place.gname
        return render_to_response('bookPlayGround.html',{'obj':obj,'val':request.session['name']})    

    # i = request.GET["yoyo"]
    # print i
    # obj = GroundDetails.objects.filter(gname=i)
    # if not obj:
    #     obj = GroundDetails.objects.filter(gtype='stadium')
    #     return render_to_response('stadiumview.html',{'obj':obj})
    # else:
    #     return render_to_response('bookStadium.html',{'obj':obj})

    # tt = GroundDetails.objects.get(gname = i)
    # ttt = tt.gtype
    # print ttt
    # print manisha.gtype
    # if manisha.gtype == 'stadium':
    #     if not obj:
    #         obj = GroundDetails.objects.filter(gtype='stadium')
    #         return render_to_response('stadiumview.html',{'obj':obj})
    #     else:    
    #         place = GroundDetails.objects.get(gname=i)
    #         idnum = place.gid
    #         grdname = place.gname
            # if not obj:
            #     obj = GroundDetails.objects.filter(gtype='stadium')
            #     return render_to_response('stadiumview.html',{'obj':obj})
            # else:
    #         return render_to_response('bookStadium.html',{'obj':obj})
    # elif manisha.gtype == 'function hall':
    #     # if manisha == 'stadium':
    #     if not obj:
    #         obj = GroundDetails.objects.filter(gtype='function hall')
    #         return render_to_response('functionview.html',{'obj':obj})
    #     else:    
    #         place = GroundDetails.objects.get(gname=i)
    #         idnum = place.gid
    #         grdname = place.gname
            # if not obj:
            #     obj = GroundDetails.objects.filter(gtype='stadium')
            #     return render_to_response('stadiumview.html',{'obj':obj})
            # else:
    #         return render_to_response('bookStadium.html',{'obj':obj})
    # elif manisha.gtype == 'play ground':
    #     # if manisha == 'stadium':
    #     if not obj:
    #         obj = GroundDetails.objects.filter(gtype='play ground')
    #         return render_to_response('playgroundview.html',{'obj':obj})
    #     else:    
    #         place = GroundDetails.objects.get(gname=i)
    #         idnum = place.gid
    #         grdname = place.gname
    #         # if not obj:
    #         #     obj = GroundDetails.objects.filter(gtype='stadium')
    #         #     return render_to_response('stadiumview.html',{'obj':obj})
    #         # else:
    #         return render_to_response('bookStadium.html',{'obj':obj})
    # return render_to_response('stadiumview.html',{'obj':obj})

def formPage(request):
    args = {}
    args.update(csrf(request))
    print ".....................lllllllllllll"
    global oldformat
    global newformat
    global gobSlot
    global zzz
    oldformat = request.GET.get('avaDate','')
    gobSlot = request.GET.get('slots','')
    print "######@@@@@@@@@@@$$$$$$$$$$ NEha #########"
    print gobSlot
    datetimeobject = datetime.strptime(oldformat,'%m/%d/%Y')
    newformat = datetimeobject.strftime('%Y-%m-%d')
    print oldformat
    inout = confirmDetails.objects.all()
    if not inout:
        return render_to_response('formPage.html',{'Dateval':newformat},context_instance=RequestContext(request))
    else:
        obj1 = confirmDetails.objects.filter(fid=idnum)
        # if not obj1
        #     return render_to_response('')
        for x in obj1:
            print type(x)
            format = str(x)
            print "final string"
            print format
            c = ","
            value = [pos for pos, char in enumerate(format) if char == c]
            print value[1]
            dt = format[value[1]+2:]
            print "final date"
            print dt
            zzz = dt[:10]
            print zzz
            # zzz = str(zzz)
            # newformat = str(newformat)
            st = format[value[2]+2:]
            print "final slot"
            print st
            print "slot in DB @@@@@ $$$$$$$$"
            print ".................."
            print dt
            print newformat
            print zzz
            print "End..............."
            if zzz == newformat:
                print "matched1"
                if st == gobSlot:
                    print "slots matched1"
                    error = "date & slot already booked"
                    return render_to_response('bookstadium.html',{'obj':obj,'val':request.session['name'],'error':error},context_instance=RequestContext(request))
                else:
                    return render_to_response('formPage.html',{'Dateval':newformat,'val':request.session['name']},context_instance=RequestContext(request))
            # elif zzz == newformat:
            #     print "matched"
            #     if st != gobSlot:
            #         print "slots matched2"
            #         return render_to_response('formPage.html',{'Dateval':newformat,'val':request.session['name']},context_instance=RequestContext(request))
            elif zzz != newformat:
                print "matcheddddddd"
                # if st == gobSlot:
                #     print "slots matched3"
                return render_to_response('formPage.html',{'Dateval':newformat,'val':request.session['name']},context_instance=RequestContext(request))
                # else:
                #     return render_to_response('formPage.html',{'Dateval':newformat,'val':request.session['name']},context_instance=RequestContext(request))
                    
            else:
                return render_to_response('dummy.html',{'obj':obj,'val':request.session['name']},context_instance=RequestContext(request))
        return render_to_response('formPage.html',{'Dateval':newformat,'val':request.session['name']},context_instance=RequestContext(request))
    return render_to_response('formPage.html',{'Dateval':newformat,'val':request.session['name']},context_instance=RequestContext(request))

def paysuccess(request):
    global msg
    global msg1
    global idnum
    c = RequestContext(request)
    # c.update(csrf(request))
    #payment
    print "pppppppppppppppppppppppppp"
    cardNum = request.POST.get('debit','')
    print cardNum
    cardCvv = request.POST.get('cvv','')
    print cardCvv

    payForm = PaymentDetails.objects.filter(paYNum=cardNum)
    print payForm
    
    for pp in payForm:
        if pp.paYNum == cardNum:
            if pp.payCvv == cardCvv:
                confirmDetails(fid=idnum,femail=email,fdate=newformat,fslots=gobSlot).save()

                gen_otp(bookemail)
                totp = pyotp.TOTP(userOtpMap[bookemail])
                msg = str(totp.now())
                
                subject = 'Please Enter the OTP'
                message= msg
                from_email = settings.EMAIL_HOST_USER
                to_list = [bookemail]
                send_mail(subject,message,from_email,to_list,fail_silently=False)
                return render_to_response('enterOTP.html',{'confirmEmail':bookemail,'val':request.session['name']})

            else:
                erCvv = "Invalid CVV"
                return render_to_response('dumcvv.html',{'errCvv':erCvv,'val':request.session['name']},context_instance=c)
        else:
            erCard = "Invalid Card Number"
            return render_to_response('dumcard.html',{'errCard':erCard,'val':request.session['name']},context_instance=c)
    erCard = "Invalid Card Number"
    return render_to_response('dumcard.html',{'errCard':erCard,'val':request.session['name']},context_instance=c)

def auth_view2(request):
    global bookemail
    global bookPhone
    global bookName

    form = BookingDetailsForm()
    if request.POST:
        form = BookingDetailsForm(request.POST)
        print form
        if form.is_valid():
            print "hi"
            form.save()
            bookemail = request.POST["bemail"]
            bookPhone = request.POST["bphone"]
            bookName  = request.POST["bname"]
            args = {}
            args.update(csrf(request))
            return render_to_response('payment.html',args)
        else:
            temp = "<html><body>Email-id or the mobile number already exists</body></html>"
            return HttpResponse(temp)
    # return render_to_response('formPage.html',{'form':form}, context_instance=RequestContext(request))

    
def success(request):
    print " in success"
    print bookemail
    print "heel"
    print msg
    otp1 = request.GET["otpvalue"]
    print "form OTP"
    print otp1
    if msg == otp1:
        global msg1
        confirmDetails(fid=idnum,femail=email,fdate=newformat,fslots=gobSlot).save()
        subject = 'Your Booking Details & Owner Details'
        gobj11 = GroundDetails.objects.get(gid=idnum)

        grndEmail = gobj11.gownemail
        print grndEmail
        grndName = gobj11.gname
        print grndName
        grndAdd = gobj11.gaddress
        print grndAdd
        grndAmt = gobj11.gamount
        print grndAmt

        
        gobj10 = OwnerDetails.objects.get(oemail= grndEmail)
        ownName = gobj10.ousername
        print ownName
        ownEmail = gobj10.oemail
        print ownEmail
        ownPh = gobj10.omobilenum
        
        #Mail to User
        msg1 = 'OWNER DETAILS: '+ " " + ownName + " " + ownEmail + " " + ownPh + " " +'GROUND DETAILS: '+" "+ grndName + " " + grndAdd + " " + grndAmt
        message= msg1
        from_email = settings.EMAIL_HOST_USER
        to_list = [bookemail]
        send_mail(subject,message,from_email,to_list,fail_silently=False)

        #Mail to Owner
        subject1 = 'User Details'
        msg2 = 'The following User Booked the below: ' + 'USER DETAILS: ' + " " + bookName + " " + bookemail + " " + bookPhone + " " + 'FOR THE GROUND' + " " + grndName + grndAdd
        message= msg2
        from_email = settings.EMAIL_HOST_USER
        to_list = [ownEmail]
        send_mail(subject1,message,from_email,to_list,fail_silently=False)
        return render_to_response('emailsuc.html',{'val':request.session['name']})
    else:
        return render_to_response('failure.html',{'confirmEmail':bookemail,'val':request.session['name']})  

          