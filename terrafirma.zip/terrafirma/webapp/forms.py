from django import forms
from .models import UserDetails,GroundDetails,BookingDetails,confirmDetails,OwnerDetails,PaymentDetails



class OwnerDetailsForm(forms.ModelForm):
	class Meta:
		model = OwnerDetails
		fields = ['ousername','oemail','opassword','omobilenum']

class GroundDetailsForm(forms.ModelForm):
    class Meta:
        model = GroundDetails
        fields = ['gownemail','gid','gtype','gname','gaddress','gamount','gpic']

class UserDetailsForm(forms.ModelForm):
    class Meta:
        model = UserDetails
        fields = ['username','email','password','mobilenum']

class confirmDetailsForm(forms.ModelForm):
	class Meta:
		model = confirmDetails
		fields = ['fid','femail','fdate','fslots']	

class BookingDetailsForm(forms.ModelForm):
	class Meta:
		model = BookingDetails
		fields =['bname','bemail','bphone']

class PaymentDetailsForm(forms.ModelForm):
	class Meta:
		model = PaymentDetails
		fields = ['paYNum','payCvv']