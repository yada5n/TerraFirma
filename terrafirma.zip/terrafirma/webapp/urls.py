from django.conf.urls import url,patterns,include
from django.conf.urls.static import static
from django.conf import settings
# from forfiles.views import ProfileImageIndexView,ProfileImageView,ProfileDetailView
from django.contrib import admin
import views
admin.autodiscover()
urlpatterns = [
	url(r'^main/$', views.main, name='main'),
	url(r'^$', views.main, name='main'),
	
	url(r'^preregister/$', views.preregister, name='preregister'),

	url(r'^signup/$', views.signup, name='signup'),
	url(r'^login/$', views.login, name='login'),
	url(r'^logout/$', views.logout, name='logout'),
	url(r'^ownlogout/$', views.ownlogout, name='ownlogout'),
	
	url(r'^ownerregister/$', views.ownerregister, name='ownerregister'),
	url(r'^signupowner/$', views.signupowner, name='signupowner'),
	url(r'^ownerlogin/$', views.ownerlogin, name='ownerlogin'),
	url(r'^grounddetails/$', views.grounddetails, name='grounddetails'),
	url(r'^checkowner/$', views.checkowner, name='checkowner'),
	url(r'^ownersuccess/$', views.ownersuccess, name='ownersuccess'),
	url(r'^ownlogin_auth_view/$', views.ownlogin_auth_view, name='ownlogin_auth_view'),
	# ownlogin_auth_view
	url(r'^gdet/$', views.gdet, name='gdet'),
	url(r'^auth_view/$', views.auth_view, name='auth_view'),
	url(r'^registration/$', views.registration, name='registration'),

	url(r'^prelogin/$', views.prelogin, name='prelogin'),


	url(r'^mainAcc/$', views.mainAcc, name='mainAcc'),
	url(r'^stadiumViews/$', views.stadiumViews, name='stadiumViews'),
	url(r'^functionViews/$', views.functionViews, name='functionViews'),
	url(r'^playGroundViews/$', views.playGroundViews, name='playGroundViews'),

	url(r'^bookStadium/$', views.bookStadium, name='bookStadium'),
	url(r'^bookFunction/$', views.bookFunction, name='bookFunction'),
	url(r'^bookPlayGround/$', views.bookPlayGround, name='bookPlayGround'),

	url(r'^formPage/$', views.formPage, name='formPage'),
	
	url(r'^auth_view2/$', views.auth_view2, name='auth_view2'),
	url(r'^success/$', views.success, name='success'),
	url(r'^paysuccess/$', views.paysuccess, name='paysuccess'),
	url(r'^index/$', views.main, name='index'),
	url(r'^functionViews/$', views.functionViews, name='functionViews'),
	url(r'^backOTP/$', views.backOTP, name='backOTP'),
	
]	




