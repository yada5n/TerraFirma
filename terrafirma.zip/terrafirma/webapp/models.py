from django.db import models
from django.conf import settings

# Create your models here.

class OwnerDetails(models.Model):
    ousername = models.CharField(max_length=20)
    oemail = models.EmailField(max_length=50,unique=True)
    opassword = models.CharField(max_length=20)
    omobilenum = models.CharField(max_length=10)
   
    def __str__(self):
        return "{0} , {1} , {2} , {3}".format(self.ousername,self.oemail,self.opassword,self.omobilenum)


class GroundDetails(models.Model):
   gownemail = models.EmailField(max_length=50)
   gid = models.IntegerField(primary_key=True)
   gtype = models.CharField(max_length=20)
   gname = models.CharField(max_length=20,unique=True)
   gaddress = models.CharField(max_length=500,unique=True)
   gamount = models.CharField(max_length=10)
   gpic = models.FileField(upload_to='')

   def __str__(self):
       return "{0} , {1} , {2} , {3} , {4} , {5} , {6}".format(self.gownemail,self.gid,self.gtype,self.gname,self.gaddress,self.gamount,self.gpic)


class UserDetails(models.Model):
    username = models.CharField(max_length=20,unique=True)
    email = models.EmailField(max_length=30,primary_key=True)
    password = models.CharField(max_length=20)
    mobilenum = models.CharField(max_length=10)
    
    def __str__(self):
    	return "{0} , {1} , {2} , {3}".format(self.username,self.email,self.password,self.mobilenum)


class confirmDetails(models.Model):
    fid = models.IntegerField()
    femail = models.EmailField(max_length=50)
    fdate = models.DateField()
    fslots = models.CharField(max_length=15)

    def __str__(self):
        return "{0} , {1} , {2} , {3}".format(self.fid,self.femail,self.fdate,self.fslots)


class BookingDetails(models.Model):
    bname = models.CharField(max_length=20)
    bemail = models.EmailField(max_length=40)
    bphone = models.CharField(max_length=15)

    def __str__(self):
        return "{0} , {1} , {2}".format(self.bname,self.bemail,self.bphone)

class PaymentDetails(models.Model):
  paYNum = models.CharField(max_length=16,unique=True)
  payCvv = models.CharField(max_length=3,unique=True)

  def __str__(self):
    return "{0} , {1}".format(self.paYNum,self.payCvv)